from flask import Flask, render_template, request
import pandas as pd
from models import ice_model, ad_model, ice_r2, ad_r2

app = Flask(__name__)

@app.route("/", methods=["GET", "POST"])
def home():
    prediction = None
    message = ""
    model_score = None

    if request.method == "POST":
        model_type = request.form["model_type"]

        if model_type == "icecream":
            temperature = float(request.form["temperature"])
            result = ice_model.predict(
                pd.DataFrame({"Temperature": [temperature]})
            )
            prediction = round(float(result[0]), 2)
            message = "Predicted Ice Cream Profits"
            model_score = round(float(ice_r2), 2)

        elif model_type == "advertising":
            tv = float(request.form["tv"])
            result = ad_model.predict(
                pd.DataFrame({"TV": [tv]})
            )
            prediction = round(float(result[0]), 2)
            message = "Predicted Advertising Sales"
            model_score = round(float(ad_r2), 2)

    return render_template(
        "index.html",
        prediction=prediction,
        message=message,
        model_score=model_score
    )

if __name__ == "__main__":
     app.run(debug=True, use_reloader=False)
