import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.metrics import r2_score, mean_squared_error, mean_absolute_error

advertising_data = pd.read_csv(r"C:\Users\anush\Downloads\linearRegression\advertising.csv")

x= advertising_data[["TV"]]
y= advertising_data["Sales"]

x_train,x_test,y_train,y_test = train_test_split(x, y, test_size=0.2, random_state=42)

ad_model = LinearRegression()
ad_model.fit(x_train,y_train)

ad_pred= ad_model.predict(x_test)
ad_r2 = r2_score(y_test, ad_pred)
ad_mae = mean_absolute_error(y_test, ad_pred)
ad_mse = mean_squared_error(y_test, ad_pred)

print("Advertising Model R2 Score:",ad_r2)
print("MAE: ", ad_mae)
print("MSE: ",ad_mse)

#dataset 2
ice_data = pd.read_csv(r"C:\Users\anush\Downloads\linearRegression\Ice Cream Sales - temperatures.csv")

x1 = ice_data[["Temperature"]]
y1 = ice_data["Ice Cream Profits"]

x1_train, x1_test, y1_train, y1_test = train_test_split(x1,y1, test_size=0.2, random_state=42)

ice_model = LinearRegression()
ice_model.fit(x1_train, y1_train)

ice_pred= ice_model.predict(x1_test)

ice_r2 = r2_score(y1_test, ice_pred)
ice_mae = mean_absolute_error(y1_test, ice_pred)
ice_mse = mean_squared_error(y1_test, ice_pred)

print("Ice Cream R2:",ice_r2)
print("Ice Cream MAE:",ice_mae)
print("Ice Cream MSE:",ice_mse)
