import gradio as gr
import pandas as pd
from models import ice_model, ad_model

def predict_ice_cream(temperature):
    result = ice_model.predict(pd.DataFrame({"Temperature": [temperature]}))
    return round(float(result[0]), 2)

def predict_sales(tv):
    result = ad_model.predict(pd.DataFrame({"TV": [tv]}))
    return round(float(result[0]), 2)

ice_app = gr.Interface(
fn=predict_ice_cream,
inputs=gr.Number(label="Temperature"),
outputs=gr.Number(label="Predicted Ice Cream Profits"),
title="Ice Cream Profit Prediction")

ad_app = gr.Interface(fn=predict_sales,inputs=gr.Number(label="TV Advertising Budget"),outputs=gr.Number(label="Predicted Sales"),title="Advertising Sales Prediction")

app = gr.TabbedInterface([ice_app, ad_app],["Ice Cream Prediction", "Advertising Prediction"])

app.launch()
